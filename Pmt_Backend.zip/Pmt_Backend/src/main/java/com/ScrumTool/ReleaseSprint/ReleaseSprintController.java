package com.ScrumTool.ReleaseSprint;

public class ReleaseSprintController {

	
}
