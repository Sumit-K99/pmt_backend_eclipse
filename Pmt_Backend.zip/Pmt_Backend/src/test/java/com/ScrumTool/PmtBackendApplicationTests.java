package com.ScrumTool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmtBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
